const API_URL = "http://localhost:3001/api/chat";

const messagesEl = document.getElementById("messages");
const formEl = document.getElementById("chat-form");
const inputEl = document.getElementById("chat-input");

let conversation = [];

function addMessage(role, text) {
  const el = document.createElement("div");
  el.className = `message ${role}`;
  el.textContent = text;
  messagesEl.appendChild(el);
  messagesEl.scrollTop = messagesEl.scrollHeight;
  return el;
}

async function sendMessage(userText) {
  conversation.push({ role: "user", content: userText });
  addMessage("user", userText);

  const loadingEl = addMessage("assistant loading", "Thinking...");
  const submitBtn = formEl.querySelector("button");
  submitBtn.disabled = true;

  try {
    const response = await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages: conversation }),
    });

    if (!response.ok) {
      throw new Error(`Server responded with ${response.status}`);
    }

    const data = await response.json();
    loadingEl.remove();
    addMessage("assistant", data.reply);
    conversation.push({ role: "assistant", content: data.reply });
  } catch (err) {
    loadingEl.remove();
    addMessage("assistant", "⚠️ Error: could not reach the server.");
    console.error(err);
  } finally {
    submitBtn.disabled = false;
  }
}

formEl.addEventListener("submit", (e) => {
  e.preventDefault();
  const text = inputEl.value.trim();
  if (!text) return;
  inputEl.value = "";
  sendMessage(text);
});
